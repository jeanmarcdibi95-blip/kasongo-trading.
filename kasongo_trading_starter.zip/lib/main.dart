import 'package:flutter/material.dart';

void main() => runApp(const KasongoTradingApp());

const gold = Color(0xFFD4AF37);
const bg = Color(0xFF080808);
const panel = Color(0xFF171717);
const muted = Color(0xFFB7B7B7);

class KasongoTradingApp extends StatelessWidget {
  const KasongoTradingApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kasongo Trading',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: const ColorScheme.dark(
          primary: gold,
          secondary: gold,
          surface: panel,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: bg,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        cardTheme: CardTheme(
          color: panel,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
            side: const BorderSide(color: Color(0xFF343434)),
          ),
        ),
        useMaterial3: true,
      ),
      home: const DashboardPage(),
    );
  }
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int selectedTab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.pets, color: gold, size: 27),
            SizedBox(width: 9),
            Text('KASONGO', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2)),
            SizedBox(width: 5),
            Text('TRADING', style: TextStyle(color: gold, fontWeight: FontWeight.w700, letterSpacing: 1)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Notifications',
            onPressed: () => _message('Les notifications seront ajoutées dans une prochaine version.'),
            icon: const Icon(Icons.notifications_none),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: SafeArea(
        child: IndexedStack(
          index: selectedTab,
          children: [
            _buildHome(),
            _buildSignals(),
            _buildSubscriptions(),
            _buildProfile(),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF111111),
        indicatorColor: gold.withOpacity(0.18),
        selectedIndex: selectedTab,
        onDestinationSelected: (index) => setState(() => selectedTab = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: gold), label: 'Accueil'),
          NavigationDestination(icon: Icon(Icons.show_chart), selectedIcon: Icon(Icons.show_chart, color: gold), label: 'Signaux'),
          NavigationDestination(icon: Icon(Icons.workspace_premium_outlined), selectedIcon: Icon(Icons.workspace_premium, color: gold), label: 'Offres'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person, color: gold), label: 'Profil'),
        ],
      ),
    );
  }

  Widget _buildHome() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: const LinearGradient(
            colors: [Color(0xFF28210D), Color(0xFF111111), Color(0xFF171717)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(color: gold.withOpacity(0.55)),
        ),
        child: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.pets, color: gold, size: 42),
            SizedBox(height: 14),
            Text('KASONGO TITAN', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
            SizedBox(height: 6),
            Text('Robot de trading automatique pour Deriv MT5', style: TextStyle(color: muted, height: 1.4)),
            SizedBox(height: 18),
            Text('DISCIPLINE  •  STRATÉGIE  •  MAÎTRISE', style: TextStyle(color: gold, fontSize: 10, letterSpacing: 1.1)),
          ],
        ),
      ),
      const SizedBox(height: 18),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(11),
                decoration: BoxDecoration(color: Colors.green.withOpacity(0.12), shape: BoxShape.circle),
                child: const Icon(Icons.shield_outlined, color: Colors.green),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('État du robot', style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: 4),
                  Text('Non connecté à MT5', style: TextStyle(color: muted, fontSize: 13)),
                ]),
              ),
              const Icon(Icons.circle, size: 10, color: Colors.orange),
              const SizedBox(width: 6),
              const Text('Démo', style: TextStyle(color: Colors.orange, fontSize: 12)),
            ],
          ),
        ),
      ),
      const SizedBox(height: 8),
      const Text('VOTRE ESPACE', style: TextStyle(color: gold, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(child: _quickTile(Icons.analytics_outlined, 'Performances', () => _message('Les statistiques seront connectées au robot plus tard.'))),
        const SizedBox(width: 10),
        Expanded(child: _quickTile(Icons.key_outlined, 'Ma licence', () => setState(() => selectedTab = 3))),
      ]),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(child: _quickTile(Icons.workspace_premium_outlined, 'Abonnements', () => setState(() => selectedTab = 2))),
        const SizedBox(width: 10),
        Expanded(child: _quickTile(Icons.help_outline, 'Assistance', () => _message('Le canal d’assistance sera configuré ensuite.'))),
      ]),
      const SizedBox(height: 18),
      const Text('À SAVOIR', style: TextStyle(color: gold, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
      const SizedBox(height: 8),
      const Text(
        'Cette version est un prototype visuel. Elle ne se connecte pas encore à un compte Deriv ou à MT5 et ne passe aucun ordre.',
        style: TextStyle(color: muted, height: 1.5, fontSize: 12),
      ),
    ],
  );

  Widget _buildSignals() => ListView(
    padding: const EdgeInsets.all(16),
    children: const [
      Text('Signaux', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      SizedBox(height: 12),
      _InfoCard(icon: Icons.sensors, title: 'Aucun signal connecté', description: 'Les signaux apparaîtront ici lorsque la liaison sécurisée avec le robot sera développée.'),
    ],
  );

  Widget _buildSubscriptions() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('Nos abonnements', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      const Text('Choisissez votre formule mensuelle.', style: TextStyle(color: muted)),
      const SizedBox(height: 18),
      _plan('STARTER', '5 000 FCFA', 'Accès au robot et à son tableau de bord'),
      _plan('PRO', '10 000 FCFA', 'Robot automatique et statistiques détaillées', featured: true),
      _plan('PREMIUM', '15 000 FCFA', 'Accès premium et assistance prioritaire'),
      const SizedBox(height: 14),
      const Text('Paiements prévus : Orange Money • MTN MoMo • Wave', style: TextStyle(color: gold, fontSize: 12)),
      const SizedBox(height: 8),
      const Text('Les paiements et l’activation des licences ne sont pas encore actifs dans ce prototype.', style: TextStyle(color: muted, fontSize: 12)),
    ],
  );

  Widget _plan(String name, String price, String description, {bool featured = false}) => Card(
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(18),
      side: BorderSide(color: featured ? gold : const Color(0xFF343434), width: featured ? 1.5 : 1),
    ),
    child: Padding(
      padding: const EdgeInsets.all(17),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (featured) const Text('LE PLUS POPULAIRE', style: TextStyle(color: gold, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1)),
        Text(name, style: const TextStyle(color: gold, fontWeight: FontWeight.bold, letterSpacing: 1.4)),
        const SizedBox(height: 5),
        Text(price, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
        const Text('/ mois', style: TextStyle(color: muted, fontSize: 12)),
        const SizedBox(height: 9),
        Text(description, style: const TextStyle(color: muted)),
        const SizedBox(height: 13),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton(
            style: OutlinedButton.styleFrom(
              foregroundColor: gold,
              side: const BorderSide(color: gold),
            ),
            onPressed: () => _message('Le paiement $name sera activé après la mise en place du système de paiement.'),
            child: const Text('Choisir cette formule'),
          ),
        ),
      ]),
    ),
  );

  Widget _buildProfile() => ListView(
    padding: const EdgeInsets.all(16),
    children: const [
      Text('Mon profil', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      SizedBox(height: 12),
      _InfoCard(icon: Icons.person_outline, title: 'Compte client', description: 'L’inscription, la connexion et la licence personnelle seront ajoutées dans la prochaine étape.'),
      _InfoCard(icon: Icons.link, title: 'Compte Deriv MT5', description: 'Aucun identifiant ni mot de passe de trading ne doit être partagé dans cette version de démonstration.'),
    ],
  );

  Widget _quickTile(IconData icon, String title, VoidCallback onTap) => Card(
    child: InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 19, horizontal: 12),
        child: Column(children: [
          Icon(icon, color: gold, size: 27),
          const SizedBox(height: 9),
          Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
        ]),
      ),
    ),
  );

  void _message(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}

class _InfoCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  const _InfoCard({required this.icon, required this.title, required this.description});

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: gold, size: 26),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Text(description, style: const TextStyle(color: muted, height: 1.4)),
        ])),
      ]),
    ),
  );
}
