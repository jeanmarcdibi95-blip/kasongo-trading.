# Kasongo Trading — prototype Flutter

## Contenu
- `lib/main.dart` : interface de démonstration noir et or.
- `pubspec.yaml` : configuration minimale Flutter.

## Lancer
1. Installer Flutter et Android Studio.
2. Décompresser ce dossier.
3. Dans le dossier du projet, exécuter `flutter pub get`.
4. Exécuter `flutter run` sur un appareil Android ou un émulateur.

## Important
Ceci est un prototype d'interface uniquement. Il ne se connecte pas à Deriv/MT5,
ne traite pas les paiements et n'active pas de licences. Les intégrations nécessitent
une API sécurisée, une validation des paiements et des tests séparés.
